param([switch]$Publish)
$ErrorActionPreference="Stop"
if($Publish){
  dotnet publish .\WoWNetworkOptimizer.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true -o .\publish
} else {
  dotnet build .\WoWNetworkOptimizer.csproj -c Release
}
