namespace WoWNetworkOptimizer.Models;
public sealed record ProcessInfo(int Id, string Name, string Path, string Status, string NetworkHint);
public sealed record ServiceInfo(int Pid, string ServiceName, string DisplayName, string State, string StartMode);
