using System.Diagnostics;
using System.Management;
using System.Text;
using WoWNetworkOptimizer.Models;

namespace WoWNetworkOptimizer.Services;

public static class SystemService
{
    public static bool IsAdmin()
    {
        try {
            using var id = System.Security.Principal.WindowsIdentity.GetCurrent();
            return new System.Security.Principal.WindowsPrincipal(id)
                .IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
        } catch { return false; }
    }

    public static List<ProcessInfo> GetInterestingProcesses()
    {
        var result = new List<ProcessInfo>();
        foreach (var p in Process.GetProcesses())
        {
            try
            {
                var n=p.ProcessName;
                if (!new[]{"wow","chrome","msedge","firefox","steam","discord","onedrive","teams","svchost","backgroundtaskhost","bitsadmin"}.Contains(n,StringComparer.OrdinalIgnoreCase))
                    continue;
                string path="";
                try { path=p.MainModule?.FileName ?? ""; } catch {}
                result.Add(new(p.Id,n,path,p.Responding?"Running":"Busy", n.Equals("wow",StringComparison.OrdinalIgnoreCase)?"PRIORIDAD WOW":"Detectado"));
            } catch {}
        }
        return result.OrderByDescending(x=>x.NetworkHint=="PRIORIDAD WOW").ThenBy(x=>x.Name).ThenBy(x=>x.Id).ToList();
    }

    public static List<ServiceInfo> GetServicesForPid(int pid)
    {
        var list=new List<ServiceInfo>();
        try
        {
            using var searcher=new ManagementObjectSearcher($"SELECT Name, DisplayName, State, StartMode, ProcessId FROM Win32_Service WHERE ProcessId={pid}");
            foreach(ManagementObject o in searcher.Get())
                list.Add(new(pid,o["Name"]?.ToString()??"",o["DisplayName"]?.ToString()??"",o["State"]?.ToString()??"",o["StartMode"]?.ToString()??""));
        } catch {}
        return list;
    }

    public static List<(int Pid,string Remote,string State,string OwningProcess)> GetConnections()
    {
        var list=new List<(int,string,string,string)>();
        try
        {
            var psi=new ProcessStartInfo("powershell.exe","-NoProfile -Command \"Get-NetTCPConnection | Select-Object OwningProcess,RemoteAddress,RemotePort,State | ConvertTo-Csv -NoTypeInformation\"")
            { UseShellExecute=false, RedirectStandardOutput=true, CreateNoWindow=true };
            using var p=Process.Start(psi)!;
            var lines=p.StandardOutput.ReadToEnd().Split(Environment.NewLine,StringSplitOptions.RemoveEmptyEntries);
            p.WaitForExit();
            foreach(var line in lines.Skip(1))
            {
                var parts=line.Trim('"').Split("\",\"");
                if(parts.Length>=4 && int.TryParse(parts[0].Trim('"'),out var pid))
                    list.Add((pid,parts[1],parts[3],pid.ToString()));
            }
        } catch {}
        return list;
    }

    public static string RunPowerShell(string command)
    {
        try
        {
            var psi=new ProcessStartInfo("powershell.exe","-NoProfile -ExecutionPolicy Bypass -Command "+Quote(command))
            { UseShellExecute=false, RedirectStandardOutput=true, RedirectStandardError=true, CreateNoWindow=true };
            using var p=Process.Start(psi)!;
            var output=p.StandardOutput.ReadToEnd();
            var error=p.StandardError.ReadToEnd();
            p.WaitForExit();
            return string.IsNullOrWhiteSpace(error)?output:error;
        } catch(Exception ex){ return ex.Message; }
    }

    static string Quote(string s) => "\""+s.Replace("\\","\\\\").Replace("\"","\\\"")+"\"";

    public static string ServiceToText(ServiceInfo s) =>
        $"{s.ServiceName} | {s.DisplayName} | Estado={s.State} | Inicio={s.StartMode}";
}
