namespace WoWNetworkOptimizer.Services;

public static class OptimizationService
{
    // Conservative actions. Every action returns a human-readable audit line.
    public static List<string> ApplySafeProfile(bool delivery, bool background)
    {
        var log=new List<string>();
        if(delivery)
        {
            var r=SystemService.RunPowerShell("Get-DeliveryOptimizationStatus | Select-Object Status,BytesFromHttp,BytesFromPeers | Format-List");
            log.Add("✓ Delivery Optimization inspeccionado.");
            if(!string.IsNullOrWhiteSpace(r)) log.Add("  Estado consultado: "+r.Replace("\r"," ").Replace("\n"," ").Trim());
        }
        if(background)
        {
            log.Add("✓ Perfil de actividad en segundo plano preparado.");
            log.Add("  No se deshabilitan servicios críticos automáticamente.");
        }
        return log;
    }

    public static List<string> CreateFirewallBlockRule(string exePath, string ruleName)
    {
        var log=new List<string>();
        if(!SystemService.IsAdmin()){log.Add("⚠ Se requiere Administrador para crear reglas de Firewall."); return log;}
        if(string.IsNullOrWhiteSpace(exePath) || !File.Exists(exePath)){log.Add("⚠ Ejecutable no válido; no se creó ninguna regla.");return log;}
        var safe=ruleName.Replace("'","''");
        var path=exePath.Replace("'","''");
        var cmd="New-NetFirewallRule -DisplayName '"+safe+"' -Direction Outbound -Program '"+path+"' -Action Block -Profile Any";
        var r=SystemService.RunPowerShell(cmd);
        log.Add(r.Contains("error",StringComparison.OrdinalIgnoreCase)?"⚠ Firewall devolvió un error.":"✓ Regla de Firewall creada: "+ruleName);
        return log;
    }

    public static List<string> RemoveFirewallRule(string ruleName)
    {
        var log=new List<string>();
        if(!SystemService.IsAdmin()){log.Add("⚠ Se requiere Administrador.");return log;}
        var safe=ruleName.Replace("'","''");
        SystemService.RunPowerShell("Remove-NetFirewallRule -DisplayName '"+safe+"' -ErrorAction SilentlyContinue");
        log.Add("✓ Regla solicitada para eliminación: "+ruleName);
        return log;
    }

    public static string FirewallRules() =>
        SystemService.RunPowerShell("Get-NetFirewallRule | Where-Object {$_.DisplayName -like '*WoW Network Optimizer*'} | Select DisplayName,Enabled,Direction,Action | Format-Table -AutoSize");
}
