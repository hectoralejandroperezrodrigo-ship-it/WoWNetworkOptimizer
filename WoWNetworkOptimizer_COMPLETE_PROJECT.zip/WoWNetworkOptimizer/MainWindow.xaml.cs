using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Threading;
using WoWNetworkOptimizer.Models;
using WoWNetworkOptimizer.Services;

namespace WoWNetworkOptimizer;

public partial class MainWindow : Window
{
    readonly ObservableCollection<ProcessInfo> processes=new();
    readonly DispatcherTimer timer=new(){Interval=TimeSpan.FromSeconds(3)};
    bool wowMode;

    public MainWindow()
    {
        InitializeComponent();
        ProcessGrid.ItemsSource=processes;
        AdminBadge.Text=SystemService.IsAdmin()?"● ADMINISTRADOR":"● USUARIO NORMAL";
        AdminBadge.Foreground=SystemService.IsAdmin() ? System.Windows.Media.Brushes.LimeGreen : System.Windows.Media.Brushes.Gold;
        timer.Tick += (_,_)=>Refresh();
        Loaded += (_,_)=>{Refresh();timer.Start();Log("✓ Aplicación iniciada.");};
    }

    void Refresh()
    {
        processes.Clear();
        foreach(var p in SystemService.GetInterestingProcesses()) processes.Add(p);
        var w=processes.Count(p=>p.Name.Equals("wow",StringComparison.OrdinalIgnoreCase));
        WowList.Text="";
        for(int i=1;i<=5;i++)
            WowList.Text += i<=w ? $"● WoW #{i}   DETECTADO   PID {processes.Where(p=>p.Name.Equals("wow",StringComparison.OrdinalIgnoreCase)).ElementAt(i-1).Id}\r\n"
                                  : $"○ WoW #{i}   ESPERANDO\r\n";
        StatusText.Text=$"{w} instancia(s) de WoW detectada(s) · {processes.Count} procesos observados";
    }

    void Log(string s){LogBox.Text=$"{DateTime.Now:HH:mm:ss}  {s}\r\n"+LogBox.Text;}

    void Scan_Click(object s,RoutedEventArgs e){Refresh();Log("✓ Escaneo completado.");}

    void Safe_Click(object s,RoutedEventArgs e)
    {
        foreach(var x in OptimizationService.ApplySafeProfile(DeliveryBox.IsChecked==true,BackgroundBox.IsChecked==true)) Log(x);
        ModeText.Text="PERFIL SEGURO";
    }

    void Max_Click(object s,RoutedEventArgs e)
    {
        if(!wowMode)
        {
            wowMode=true; ModeText.Text="🚀 MODO WOW";
            Log("✓ Modo WoW activado.");
            Log("✓ Las instancias detectadas quedan marcadas como objetivo prioritario.");
            Log("⚠ El programa no mata svchost ni servicios críticos automáticamente.");
            if(FirewallBox.IsChecked==true) Log("⚠ Firewall activado en preferencias: crea reglas sólo cuando se elija un ejecutable.");
        }
        else {wowMode=false;ModeText.Text="NORMAL";Log("↩ Modo WoW desactivado.");}
    }

    void Svchost_Click(object s,RoutedEventArgs e)
    {
        if(!int.TryParse(SvchostPid.Text,out var pid)){MessageBox.Show("Escribe un PID de svchost.");return;}
        ServiceGrid.ItemsSource=SystemService.GetServicesForPid(pid);
        Log($"🔎 Servicios enumerados dentro de svchost PID {pid}.");
    }

    void Connections_Click(object s,RoutedEventArgs e)
    {
        var data=SystemService.GetConnections().Select(x=>new{PID=x.Pid,Remoto=x.Remote,Estado=x.State}).ToList();
        ConnGrid.ItemsSource=data; Log("✓ Conexiones TCP actualizadas.");
    }

    void Rules_Click(object s,RoutedEventArgs e)
    {
        RulesBox.Text=OptimizationService.FirewallRules();
        Log("✓ Reglas del optimizador consultadas.");
    }

    void Restore_Click(object s,RoutedEventArgs e)
    {
        wowMode=false;ModeText.Text="NORMAL";
        Log("↩ Perfil visual restaurado. No se ejecutan restauraciones destructivas automáticas.");
        RulesBox.Text="";
    }
}
