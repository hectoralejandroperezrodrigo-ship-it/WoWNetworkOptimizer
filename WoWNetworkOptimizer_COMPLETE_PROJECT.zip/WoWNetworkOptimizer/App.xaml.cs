using System.Windows;
namespace WoWNetworkOptimizer;
public partial class App : Application { }
