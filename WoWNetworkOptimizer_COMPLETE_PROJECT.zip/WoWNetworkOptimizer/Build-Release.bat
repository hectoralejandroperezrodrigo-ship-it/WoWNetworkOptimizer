@echo off
echo WoW Network Optimizer - compilacion Release
dotnet build "%~dp0WoWNetworkOptimizer\WoWNetworkOptimizer.csproj" -c Release
pause
