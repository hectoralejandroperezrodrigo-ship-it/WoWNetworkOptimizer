# WoW Network Optimizer — Complete

## Objetivo
Panel Windows 10/11 para diagnosticar y controlar el tráfico alrededor de cinco instancias de WoW Lich King.

## Funciones incluidas
- Interfaz WPF oscura.
- Detección continua de procesos.
- Identificación de hasta cinco instancias WoW.
- PID, ruta y estado de procesos.
- Enumeración de servicios alojados dentro de un `svchost.exe` por PID mediante WMI.
- Consulta de conexiones TCP y PID propietario.
- Consulta de Delivery Optimization.
- Perfil seguro y modo WoW.
- Auditoría visible de cada acción.
- Módulo para reglas de Windows Firewall.
- Detección de privilegios de administrador.
- Código separado por servicios/modelos para ampliar el proyecto.

## Compilación
Recomendado: Visual Studio 2022 con "Desarrollo de escritorio de .NET" y .NET 8 SDK.

Abrir `WoWNetworkOptimizer.csproj` y pulsar Compilar.

También:
`dotnet build -c Release`

## Importante
Windows no expone de forma simple un contador universal y exacto de bytes por proceso para todos los escenarios. Para una medición de tráfico por proceso de nivel avanzado se necesita ETW/WFP u otra instrumentación. Este proyecto deja preparada la arquitectura para añadirla.

### svchost
Un PID de svchost puede hospedar varios servicios. El programa permite enumerarlos antes de tomar decisiones. No se recomienda "matar svchost" ni detener servicios de raíz sin identificar primero el servicio y sus dependencias.

### Firewall
Las reglas reales requieren privilegios de administrador. No se crean bloqueos globales automáticamente.

### Restauración
La versión base evita cambios destructivos automáticos. Antes de añadir automatización agresiva conviene guardar un inventario de estado y generar reglas reversibles.
